const { getDB } = require('../db/database');
const logger = require('../utils/logger');
const reviewSummaryService = require('./reviewSummary.service');

/**
 * Create Review (DEFAULT = pending)
 */
const createReview = async (data) => {
    try {
        const db = getDB();

        const [result] = await db.execute(
            `INSERT INTO reviews (
                uuid, user_id, user_name, entity_id, entity_type,
                rating, title, comment,
                status, is_verified_purchase, is_anonymous,
                ip_address, user_agent, created_by,
                view_count
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
            [
                data.uuid,
                data.user_id,
                data.user_name || `User_${data.user_id}`,
                data.entity_id,
                data.entity_type,
                data.rating,
                data.title || null,
                data.comment || null,
                'approved', // ✅ important
                data.is_verified_purchase || false,
                data.is_anonymous || false,
                data.ip_address || null,
                data.user_agent || null,
                data.created_by || null,
                0
            ]
        );

        await reviewSummaryService.updateReviewSummary(
            data.entity_id,
            data.entity_type
        );

        return result.insertId;

    } catch (error) {
        logger.error('Create Review DB Error', error);
        throw error;
    }
};

/**
 * Get ONLY approved reviews
 */
const getReviews = async ({ page = 1, limit = 10 }) => {
    const db = getDB();
    const offset = (page - 1) * limit;

    const [rows] = await db.execute(`
        SELECT * FROM reviews 
        WHERE deleted_at IS NULL
        AND status = 'approved'
        ORDER BY created_at DESC
        LIMIT ${limit} OFFSET ${offset}
    `);

    const [[count]] = await db.execute(
        `SELECT COUNT(*) as total FROM reviews 
         WHERE deleted_at IS NULL AND status = 'approved'`
    );

    return { data: rows, total: count.total, page, limit };
};

/**
 * Get Review By ID
 */
/**
 * Get Single Review
 */
const getReviewById = async (id) => {
    try {
        const db = getDB();

        const [rows] = await db.execute(
            `SELECT * FROM reviews 
             WHERE id = ? AND deleted_at IS NULL`,
            [id]
        );

        // ✅ always return safe value
        if (!rows || rows.length === 0) {
            return null;
        }

        return rows[0];

    } catch (error) {
        logger.error('Get Review By ID Error', error);
        throw error;
    }
};

/**
 * 🔥 Get Pending Reviews
 */
const getPendingReviews = async () => {
    const db = getDB();

    const [rows] = await db.execute(`
        SELECT * FROM reviews 
        WHERE status = 'pending'
        AND deleted_at IS NULL
        ORDER BY created_at DESC
    `);

    return rows;
};

/**
 * Approve Review
 */
const approveReview = async (id) => {
    const db = getDB();

    const [result] = await db.execute(
        `UPDATE reviews SET status='approved' WHERE id=?`,
        [id]
    );

    return result.affectedRows;
};

/**
 * Reject Review
 */
const rejectReview = async (id) => {
    const db = getDB();

    const [result] = await db.execute(
        `UPDATE reviews SET status='rejected' WHERE id=?`,
        [id]
    );

    return result.affectedRows;
};

/**
 * Increment View Count
 */
const incrementReviewView = async (id) => {
    try {
        const db = getDB();

        const [result] = await db.execute(
            `UPDATE reviews 
             SET view_count = view_count + 1 
             WHERE id = ? AND deleted_at IS NULL`,
            [id]
        );

        return result.affectedRows;

    } catch (error) {
        logger.error('Increment View Error', error);
        throw error;
    }
};

/**
 * 🔥 SEARCH REVIEWS (FIX)
 */
const searchReviews = async (filters) => {
    const db = getDB();

    let query = `
        SELECT * FROM reviews
        WHERE deleted_at IS NULL
        AND status = 'approved'
    `;

    const values = [];

    if (filters.search) {
        query += ` AND (title LIKE ? OR comment LIKE ?)`;
        values.push(`%${filters.search}%`, `%${filters.search}%`);
    }

    query += ` ORDER BY created_at DESC`;

    const [rows] = await db.execute(query, values);

    return rows;
};

/**
 * Delete Review (Soft Delete)
 */
const deleteReview = async (id, deleted_by) => {
    const db = getDB();

    const [[existing]] = await db.execute(
        `SELECT entity_id, entity_type FROM reviews WHERE id = ?`,
        [id]
    );

    const [result] = await db.execute(
        `UPDATE reviews 
         SET deleted_at = NOW(), deleted_by = ?
         WHERE id = ? AND deleted_at IS NULL`,
        [deleted_by ?? null, id]
    );

    if (result.affectedRows && existing) {
        await reviewSummaryService.updateReviewSummary(
            existing.entity_id,
            existing.entity_type
        );
    }

    return result.affectedRows;
};

/**
 * 🔥 COUNT BY TYPE (FIX)
 */
const getReviewCountByType = async (entity_type) => {
    const db = getDB();

    const [[result]] = await db.execute(
        `SELECT COUNT(*) as total_reviews 
         FROM reviews 
         WHERE entity_type=? 
         AND status='approved' 
         AND deleted_at IS NULL`,
        [entity_type]
    );

    return result;
};

/**
 * Update Review
 */
const updateReview = async (id, data) => {
    const db = getDB();

    const [result] = await db.execute(
        `UPDATE reviews SET
            rating = ?,
            comment = ?,
            updated_by = ?
         WHERE id = ? AND deleted_at IS NULL`,
        [
            data.rating,
            data.comment,
            data.updated_by || 1,
            id
        ]
    );

    return result.affectedRows;
};

/**
 * Restore Review (Undo Soft Delete)
 */
const restoreReview = async (id) => {
    const db = getDB();

    // Get entity info before restore (for summary update)
    const [[existing]] = await db.execute(
        `SELECT entity_id, entity_type FROM reviews WHERE id = ?`,
        [id]
    );

    const [result] = await db.execute(
        `UPDATE reviews 
         SET deleted_at = NULL, deleted_by = NULL
         WHERE id = ? AND deleted_at IS NOT NULL`,
        [id]
    );

    if (result.affectedRows && existing) {
        await reviewSummaryService.updateReviewSummary(
            existing.entity_id,
            existing.entity_type
        );
    }

    return result.affectedRows;
};

module.exports = {
    createReview,
    getReviews,
    getReviewById,
    incrementReviewView,
    searchReviews,           // ✅ FIXED
    getReviewCountByType,    // ✅ FIXED
    getPendingReviews,
    approveReview,
    rejectReview,
    deleteReview,
    updateReview,
    restoreReview
};