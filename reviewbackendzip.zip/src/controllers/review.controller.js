const reviewService = require('../services/review.service');
const { v4: uuidv4 } = require('uuid');

/**
 * Create Review
 */
const createReview = async (req, res) => {
    try {
        const { user_id, entity_id, entity_type, rating } = req.body;

        if (!user_id || !entity_id || !entity_type || rating == null) {
            return res.status(400).json({
                success: false,
                message: 'Required fields missing'
            });
        }

        const data = {
            ...req.body,
            uuid: uuidv4(),
            user_name: req.body.user_name || `User_${user_id}`,
            ip_address: req.ip,
            user_agent: req.headers['user-agent'],
            created_by: user_id
        };

        const id = await reviewService.createReview(data);

        res.json({
            success: true,
            id
        });

    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
};

/**
 * Get Reviews (ONLY approved)
 */
const getReviews = async (req, res) => {
    try {
        const data = await reviewService.getReviews({
            page: req.query.page,
            limit: req.query.limit
        });

        res.json({ success: true, ...data });

    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
};

/**
 * Get Single Review
 */
const getReviewById = async (req, res) => {
    try {
        const id = req.params.id;

        if (!id) {
            return res.status(400).json({
                success: false,
                message: "Review ID is required"
            });
        }

        const data = await reviewService.getReviewById(id);

        // ✅ SAFE CHECK
        if (!data) {
            return res.status(404).json({
                success: false,
                message: "Review not found"
            });
        }

        res.json({
            success: true,
            data
        });

    } catch (error) {
        console.error("GET BY ID ERROR:", error); // 🔥 debug log

        res.status(500).json({
            success: false,
            message: error.message || "Internal Server Error"
        });
    }
};

/**
 * Increment View Count
 */
const incrementReviewView = async (req, res) => {
    try {
        const affected = await reviewService.incrementReviewView(req.params.id);

        if (!affected) {
            return res.status(404).json({
                success: false,
                message: "Review not found"
            });
        }

        res.json({
            success: true,
            message: "View count updated"
        });

    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
};

/**
 * Delete Review
 */
const deleteReview = async (req, res) => {
    try {
        const affected = await reviewService.deleteReview(req.params.id, 1);

        if (!affected) {
            return res.status(404).json({
                success: false,
                message: "Review not found"
            });
        }

        res.json({
            success: true,
            message: "Deleted successfully"
        });

    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
};

/**
 * 🔥 ADMIN: Get Pending
 */
const getPendingReviews = async (req, res) => {
    try {
        const data = await reviewService.getPendingReviews();

        res.json({
            success: true,
            data
        });

    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
};

/**
 * 🔥 ADMIN: Approve
 */
const approveReview = async (req, res) => {
    try {
        await reviewService.approveReview(req.params.id);

        res.json({
            success: true,
            message: "Approved"
        });

    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
};

/**
 * 🔥 ADMIN: Reject
 */
const rejectReview = async (req, res) => {
    try {
        await reviewService.rejectReview(req.params.id);

        res.json({
            success: true,
            message: "Rejected"
        });

    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
};

/**
 * Update Review
 */
const updateReview = async (req, res) => {
    try {
        const affected = await reviewService.updateReview(req.params.id, {
            ...req.body,
            updated_by: 1
        });

        if (!affected) {
            return res.status(404).json({
                success: false,
                message: "Review not found"
            });
        }

        res.json({
            success: true,
            message: "Updated successfully"
        });

    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
};

/**
 * Restore Review
 */
const restoreReview = async (req, res) => {
    try {
        const affected = await reviewService.restoreReview(req.params.id);

        if (!affected) {
            return res.status(404).json({
                success: false,
                message: "Review not found or already active"
            });
        }

        res.json({
            success: true,
            message: "Review restored successfully"
        });

    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
};

module.exports = {
    createReview,
    getReviews,
    getReviewById,
    incrementReviewView,
    deleteReview,

    // 🔥 ADMIN
    getPendingReviews,
    approveReview,
    rejectReview,
    updateReview,
    restoreReview
};