const express = require('express');
const router = express.Router();

const reviewController = require('../controllers/review.controller');

// ==========================
// CREATE
// ==========================
router.post('/', reviewController.createReview);

// ==========================
// VIEW COUNT
// ==========================
router.post('/:id/view', reviewController.incrementReviewView);

// ==========================
// 🔥 ADMIN ROUTES
// ==========================
router.get('/pending', reviewController.getPendingReviews);
router.put('/:id/approve', reviewController.approveReview);
router.put('/:id/reject', reviewController.rejectReview);

// ==========================
// DELETE & RESTORE
// ==========================
router.delete('/:id', reviewController.deleteReview);
router.put('/:id/restore', reviewController.restoreReview); // ✅ MUST BE BEFORE /:id

// ==========================
// UPDATE
// ==========================
router.put('/:id', reviewController.updateReview);

// ==========================
// PUBLIC ROUTES
// ==========================
router.get('/', reviewController.getReviews);

// ⚠️ ALWAYS LAST
router.get('/:id', reviewController.getReviewById);

module.exports = router;